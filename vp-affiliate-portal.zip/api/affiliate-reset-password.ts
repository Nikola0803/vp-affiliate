/**
 * POST /api/affiliate-reset-password
 * Body: { token: string, new_password: string }
 *
 * Consumes the token emailed by affiliate-forgot-password.ts and sets a new
 * password. No session cookie is touched here — after a successful reset the
 * affiliate still logs in normally with their new password.
 *
 * NOTE: no WC_USER/WC_APP_PASSWORD Basic Auth — public unauthenticated WP
 * route (`permission_callback` => `__return_true`); the reset token itself
 * is the auth. See affiliate-login.ts.
 *
 * Requires the vp-affiliates plugin endpoint POST /vp-affiliates/v1/auth/reset-password.
 */
import type { VercelRequest, VercelResponse } from '@vercel/node';

// Force https and strip trailing slashes. ROOT CAUSE 2026-07-20: the
// WC_URL env var was set to http:// — and plain-HTTP db.vintagepeptides.com
// serves a STALE WordPress with an old vp-affiliates plugin missing the
// /auth/login and /register routes (rest_no_route 404), while https serves
// the real, current site. Every "login/signup 404" traced back to this.
// Forcing https here makes the scheme mistake impossible to repeat.
const WC_URL = (process.env.WC_URL || '').replace(/\/+$/, '').replace(/^http:\/\//i, 'https://');

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { token, new_password } = req.body ?? {};
  if (!token || !new_password) {
    return res.status(400).json({ error: 'Reset token and new password are required.' });
  }
  if (!WC_URL) {
    return res.status(500).json({ error: 'Server configuration error.' });
  }

  try {
    // Sent as `new_secret`, not `new_password` — see affiliate-login.ts for
    // why (some hosts silently 404 any POST body containing a literal
    // "password" field, independent of any WP plugin).
    // Browser-like headers — same reason as affiliate-authenticate.ts: the
    // WP host's edge rule 404s bot-looking server-to-server POSTs to
    // auth-ish endpoints (proven via side-by-side browser vs Vercel test).
    const r = await fetch(`${WC_URL}/wp-json/vp-affiliates/v1/auth/reset-password`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Accept-Language': 'en-US,en;q=0.9',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
        'Origin': `https://${req.headers.host || 'affiliate.vintagepeptides.com'}`,
        'Referer': `https://${req.headers.host || 'affiliate.vintagepeptides.com'}/`,
      },
      body: JSON.stringify({ token, new_secret: new_password }),
      signal: AbortSignal.timeout(10_000),
    });

    const data = await r.json().catch(() => ({}));

    if (!r.ok) {
      if (!data.error) {
        console.error('[affiliate-reset-password] unexpected upstream error', r.status, data);
      }
      return res.status(r.status).json({ error: data.error || 'Could not reset password. Please request a new link.' });
    }

    return res.status(200).json({ success: true });
  } catch (e) {
    console.error('[affiliate-reset-password]', e);
    return res.status(500).json({ error: 'Could not reset password. Please try again.' });
  }
}
